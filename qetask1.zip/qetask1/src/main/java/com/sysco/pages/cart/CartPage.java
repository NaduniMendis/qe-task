package com.sysco.pages.cart;

import com.sysco.pages.account.MyaccountPage;
import org.openqa.selenium.By;
public class CartPage extends MyaccountPage {


    private By iconCart=By.xpath("//*[@id=\"cartHeader\"]");
    private By popupCart= By.id("topCartContent");
    private By btnRemove= By.id("cartheader-item-311487");

    public void gotoCart() {
        syscoLabUIOgm.findElement(iconCart).click();

    }

    public boolean checkCartpopup() {

        syscoLabUIOgm.waitTillElementLoaded(popupCart);
        return syscoLabUIOgm.findElement(popupCart).isDisplayed();
    }

    public void clickRemove() {
        syscoLabUIOgm.findElement(btnRemove).click();
        syscoLabUIOgm.isAlertDisplayed();
        syscoLabUIOgm.clickOkInWindowsAlert();



    }

    public boolean checkCartempty() {
        return !syscoLabUIOgm.findElement(btnRemove).isDisplayed();
    }
}
