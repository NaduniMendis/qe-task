package com.sysco.data;

public class LoginData {

    public static String ref;
    public static String box;
    public static String userName;
    public static String password;
    public static String iPAddress;

}
