package com.sysco.tests.cart;

import com.sysco.functions.account.Myaccount;
import com.sysco.functions.cart.Cart;
import com.sysco.functions.home.Home;
import com.sysco.utils.TestBase;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class CartTest extends TestBase {

    SoftAssert sAssert = new SoftAssert();
    @BeforeClass
    public void setUp() {
        Home.loadHomePage();
        Home.ageCheck(5,5,12);
        Home.clickSubmit();
        Home.checkLoadpage();
        Myaccount.clickAccount();
        Myaccount.enterEmail("williamjacob802@gmail.com");
        Myaccount.enterPassword("12345678");
    }

    @Test (priority = 0)
    public void testCart() {
        Cart.openCart();
        sAssert.assertEquals(Cart.verifyCartpopup(),true, "Cart popup failed");
    }

    @Test (priority = 1)
    public void removeCartItem(){
        Cart.removeItem();
        sAssert.assertEquals(Cart.verifyEmptycart(), false, "Item removal failed");


    }
}
